
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                            main.c
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                                                    Forrest Yu, 2005
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

#include "type.h"
#include "stdio.h"
#include "const.h"
#include "protect.h"
#include "string.h"
#include "fs.h"
#include "proc.h"
#include "tty.h"
#include "console.h"
#include "global.h"
#include "proto.h"


void intToStr (int n,char str[]) {
 
        int i=0,j,len,m=n;
        char tmp;
        if(n<0) {
                str[0]='-';
                str[1]='\0';
                i++;
                n=-n;
        }
 
        do {
                str[i]=(n%10+0x30);
                n/=10;
                i++;
        }while(n!=0);
        str[i]='\0';
 
        len=i;
 
        if(m<0) {
                i=1;
        }else{
                i=0;
        }
 
        for(j=len-1;i<len/2;i++,j--) {
                tmp=str[i];
                str[i]=str[j];
                str[j]=tmp;
        }
 
}

void game(fd_stdin, fd_stdout){
	int fd;
	int n;
	const char filename[] = "abc";
	char* bufw = "0";
	int rd_bytes = 1;
	char bufr[rd_bytes];

	char rdbuf[128];	

	//assert(rd_bytes <= strlen(bufw));

	/* open */
	fd = open(filename, O_RDWR);
	assert(fd != -1);
	//printf("File opened. fd: %d\n", fd);
	
	n = write(fd, bufw, strlen(bufw));

	close(fd);

	/* open */
	fd = open(filename, O_RDWR);
	assert(fd != -1);

	/* read */
	n = read(fd, bufr, rd_bytes);
	assert(n == rd_bytes);
	bufr[n] = 0;
	printf("%d bytes read: %s\n", n, bufr);

	/* close */
	close(fd);	

	//printf("\n");
	//int x;
	//atoi(bufr,&x);
	//printf("%d",x);
}

//优先级越高,时间片越小
void addToQueue(struct proc* p)
{
	p->state=kRUNNABLE;
	if (p->priority>=10)
	{
		firstQueue[firstLen]=p;
		firstLen++;
		p->ticks=2;
		p->whichQueue=1;
	}
	else if (p->priority>=5)
	{
		secondQueue[secondLen]=p;
		secondLen++;
		p->ticks=3;
		p->whichQueue=2;
	}
	else 
	{
		thirdQueue[thirdLen]=p;
		thirdLen++;
		p->ticks=p->priority;
		p->whichQueue=3;
	}
}

void sec_delay(int seconds)
{
	int i=0;
        while(i < seconds * 2000000)
	{
		i++;
	}

}


/*======================================================================*
                            kernel_main
 *======================================================================*/
PUBLIC int kernel_main()
{
	//disp_str("-----\"kernel_main\" begins-----\n");

	clearScreen();
	//sec_delay(2);
	//clearScreen();
	//DisPlayAnimation();
	
	struct task* p_task;
	struct proc* p_proc= proc_table;
	char* p_task_stack = task_stack + STACK_SIZE_TOTAL;
	u16   selector_ldt = SELECTOR_LDT_FIRST;
        u8    privilege;
        u8    rpl;
	int   eflags;
	int   i, j;
	int   prio;
	for (i = 0; i < NR_TASKS+NR_PROCS; i++) {
	        if (i < NR_TASKS) {     /* 任务 */
                        p_task    = task_table + i;
                        privilege = PRIVILEGE_TASK;
                        rpl       = RPL_TASK;
                        eflags    = 0x1202; /* IF=1, IOPL=1, bit 2 is always 1 */
			prio      = 15;
                }
                else {                  /* 用户进程 */
                        p_task    = user_proc_table + (i - NR_TASKS);
                        privilege = PRIVILEGE_USER;
                        rpl       = RPL_USER;
                        eflags    = 0x202; /* IF=1, bit 2 is always 1 */
			prio      = 5;
                }

		strcpy(p_proc->name, p_task->name);	/* name of the process */
		p_proc->pid = i;			/* pid */

		p_proc->ldt_sel = selector_ldt;

		memcpy(&p_proc->ldts[0], &gdt[SELECTOR_KERNEL_CS >> 3],
		       sizeof(struct descriptor));
		p_proc->ldts[0].attr1 = DA_C | privilege << 5;
		memcpy(&p_proc->ldts[1], &gdt[SELECTOR_KERNEL_DS >> 3],
		       sizeof(struct descriptor));
		p_proc->ldts[1].attr1 = DA_DRW | privilege << 5;
		p_proc->regs.cs	= (0 & SA_RPL_MASK & SA_TI_MASK) | SA_TIL | rpl;
		p_proc->regs.ds	= (8 & SA_RPL_MASK & SA_TI_MASK) | SA_TIL | rpl;
		p_proc->regs.es	= (8 & SA_RPL_MASK & SA_TI_MASK) | SA_TIL | rpl;
		p_proc->regs.fs	= (8 & SA_RPL_MASK & SA_TI_MASK) | SA_TIL | rpl;
		p_proc->regs.ss	= (8 & SA_RPL_MASK & SA_TI_MASK) | SA_TIL | rpl;
		p_proc->regs.gs	= (SELECTOR_KERNEL_GS & SA_RPL_MASK) | rpl;

		p_proc->regs.eip = (u32)p_task->initial_eip;
		p_proc->regs.esp = (u32)p_task_stack;
		p_proc->regs.eflags = eflags;

		/* p_proc->nr_tty		= 0; */

		p_proc->p_flags = 0;
		p_proc->p_msg = 0;
		p_proc->p_recvfrom = NO_TASK;
		p_proc->p_sendto = NO_TASK;
		p_proc->has_int_msg = 0;
		p_proc->q_sending = 0;
		p_proc->next_sending = 0;

		for (j = 0; j < NR_FILES; j++)
			p_proc->filp[j] = 0;

		p_proc->ticks = p_proc->priority = prio;

		p_task_stack -= p_task->stacksize;
		p_proc++;
		p_task++;
		selector_ldt += 1 << 3;
	}

       //修改这里的优先级和ticks
	proc_table[0].priority = 15;
	proc_table[1].priority =  5;
	proc_table[2].priority =  2;
	proc_table[3].priority =  3;
	proc_table[4].priority =  7;
	proc_table[5].priority =  10;
	proc_table[6].priority =  20;
	proc_table[7].priority =  8;
	proc_table[8].priority =  8;
	//proc_table[9].priority =  12;//ABCD


	firstLen=firstHead=secondLen=thirdLen=0;
	for (i=0; i<NR_TASKS+NR_PROCS;i++)
	{
		addToQueue(proc_table+i);
	}
	//指定控制台
	proc_table[1].nr_tty = 0;
	proc_table[2].nr_tty = 1;
	proc_table[3].nr_tty = 1;
	proc_table[4].nr_tty = 1;
	proc_table[5].nr_tty = 1;
	proc_table[6].nr_tty = 2; 
   	proc_table[7].nr_tty = 3; 
	proc_table[8].nr_tty = 4; 
	//proc_table[9].nr_tty = 5;

	k_reenter = 0;
	ticks = 0;

	p_proc_ready	= proc_table;

	init_clock();
        init_keyboard();

	restart();

	while(1){}
}


/*****************************************************************************
 *                                get_ticks
 *****************************************************************************/
PUBLIC int get_ticks()
{
	MESSAGE msg;
	reset_msg(&msg);
	msg.type = GET_TICKS;
	send_recv(BOTH, TASK_SYS, &msg);
	return msg.RETVAL;
}


/*======================================================================*
                               TestA
 *======================================================================*/
void TestA()
{
	
	DisPlayAnimation();
	int fd;
	int i, n;

	char tty_name[] = "/dev_tty0";

	char rdbuf[128];


	int fd_stdin  = open(tty_name, O_RDWR);
	assert(fd_stdin  == 0);
	int fd_stdout = open(tty_name, O_RDWR);
	assert(fd_stdout == 1);

//	char filename[MAX_FILENAME_LEN+1] = "zsp01";
	const char bufw[80] = {0};
//	const int rd_bytes = 3;
//	char bufr[rd_bytes];

	//sec_delay(2);
	//DisPlayAnimation();
	clear();
	clearScreen();

	help();

	printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
	
	while (1) {           
		printf(" bochs:-$ ");


		int r = read(fd_stdin, rdbuf, 70);
		rdbuf[r] = 0;
		//show();
       		if (strcmp(rdbuf, "help") == 0)
		{
			help();
		}
		else if (strcmp(rdbuf, "t") == 0)
		{
			timer(fd_stdin, fd_stdout);
		}
		else if(strcmp(rdbuf, "game") == 0){
			clear();
			game(fd_stdin, fd_stdout);
		}
		
		else if (strcmp(rdbuf, "clear") == 0)
		{
			clear();
		}
		else if (strcmp(rdbuf, "exit") == 0)
		{
			displayGoodBye();
		}
		else if (strcmp(rdbuf, "calendar") == 0)
		{
			calendar(fd_stdin, fd_stdout);
		}
		else if (strcmp(rdbuf, "show") == 0)
		{
			show();
		}
		else if (strcmp(rdbuf, "chess") == 0)
		{
			chess(fd_stdin, fd_stdout);
		}
		else if (rdbuf[0]=='k'&&rdbuf[1]=='i')
		{
			int number;
			atoi(rdbuf+5,&number);
			if (number<0 || number>NR_TASKS+NR_PROCS)
			{
				printf("No found this process!!");
			}
			else if (number==0)
			{
				printf("You do not have sufficient privileges\n");
			}
			else if (5<=number && number <=7)
			{
				proc_table[number].state=kREADY;
				printf("kill process %d successful\n",number);
			}
		}
		else if (rdbuf[0]=='s'&&rdbuf[1]=='t')
		{
			int number;
			atoi(rdbuf+6,&number);
			if (number<0 || number>NR_TASKS+NR_PROCS)
			{
				printf("No found this process!!");
			}
			else if (number==0)
			{
				printf("You do not have sufficient privileges\n");
			}
			else if (5<=number && number <=7)
			{
				proc_table[number].state=kRUNNING;
				printf("start process %d successful\n",number);
			}
		}
		

		else
			printf("Command not found, please check!\n");
	}
}

void show()
{
	struct proc *p;
	int i;
	for (i=0; i<NR_TASKS+NR_PROCS;i++)
	{
		p=&proc_table[i];
		printf("process%d:",p->pid);
		printf("  %s:",p->name);
		switch (p->state)
		{
		case kRUNNABLE:
			printf("    Runnable\n");
			break;
		case kRUNNING:
			printf("    Running\n");
			break;
		case kREADY:
			printf("    Ready\n");
			break;
		}
	}
}

char chessMap[13][13];
TTY *chessTty=tty_table+3;

void display()
{
	sys_clear(chessTty);
	int n=13;
	int i,j;
	for (i=0; i<=n; i++)
	{
		if (i<10) 
			printf("%d   ",i);
		else 
			printf("%d  ",i);
	}
	printf("\n");
	for (i=0; i<n; i++)
	{
		if (i<9) 
			printf("%d   ",i+1);
		else 
			printf("%d  ",i+1);
		for (j=0; j<n; j++)
		{
			if (j<10)
			 	printf("%c   ",chessMap[i][j]);
			else 
				printf("%c   ",chessMap[i][j]);
		}
		printf("\n");
	}
}

int check(int x, int y)	//检查玩家输入的参数是否正确
{
	int n=13;
	if (x<0 || y<0 || x>=n || y>=n) return 0;
	if (chessMap[x][y]!='*') return 0;
	return 1;
}

int isWin(int x,int y)
{
	int n=15;
	int i,j;
	int count;

	count=1;
	for (j=y+1; j<n; j++)
	{
		if (chessMap[x][j]==chessMap[x][y]) count++;
		else break;
	}
	for (j=y-1; j>=0; j--)
	{
		if (chessMap[x][j]==chessMap[x][y]) count++;
		else break;
	}
	if (count>=5) return 1;

	count=1;
	for (i=x-1; i>0; i--)
	{
		if (chessMap[i][y]==chessMap[x][y]) count++;
		else break;
	}
	for (i=x+1; i<n; i++)
	{
		if (chessMap[i][y]==chessMap[x][y]) count++;
		else break;
	}
	if (count>=5) return 1;

	count=1;
	for (i=x-1,j=y-1; i>=0 && j>=0; i--,j--)
	{
		if (chessMap[i][j]==chessMap[x][y]) count++;
		else break;
	}
	for (i=x+1,j=y+1; i<n && j<n; i++,j++)
	{
		if (chessMap[i][j]==chessMap[x][y]) count++;
		else break;
	}
	if (count>=5) return 1;

	count=1;
	for (i=x-1,j=y+1; i>=0 && j<n; i--,j++)
	{
		if (chessMap[i][j]==chessMap[x][y]) count++;
		else break;
	}
	for (i=x+1,j=y-1; i<n && j>=0; i++,j--)
	{
		if (chessMap[i][j]==chessMap[x][y]) count++;
		else break;
	}
	if (count>=5) return 1;

	return 0;
}

void chess(int fd_stdin,int fd_stdout)
{
	int playerOneStep=0;
	int playerTwoStep=0;
	int n=13;
	int i,j;
	clear();
	clearScreen();

	char rdbuf[128];

	int end=0;

	while(1)
	{

		if(end==1){
			help();
			break;
		}		

		for (i=0; i<n; i++)
			for (j=0; j<n; j++)
				chessMap[i][j]='*';

		display();

		while(1)
		{
			int x,y;
			while(1)
			{
				printf("\n\n\n");
				printf("[player1 step%d] ",++playerOneStep);
				int r = read(fd_stdin, rdbuf, 70);
				rdbuf[r] = 0;

				if(strcmp(rdbuf, "end") == 0)
				{
					end=1;
					break;
				}
				atoi(rdbuf,&x);
				if(x>=10)
					atoi(rdbuf+3,&y);
				else 
					atoi(rdbuf+2,&y);
				x--;
				y--;
				if (check(x,y) )
				{
					chessMap[x][y]='o';
					break;
				}
				else
				{
					playerOneStep--;
					printf("wrong position\n");
				}
			}
			if(end==1)
				break;
			if (isWin(x,y))
			{
				display();
				printf("player1 won the game\n");
				break;
			}
			display();
			while(1)
			{
				printf("\n\n\n");
				printf("[player2 step%d] ",++playerTwoStep);
				int r = read(fd_stdin, rdbuf, 70);
				rdbuf[r] = 0;

				if(strcmp(rdbuf, "end") == 0)
				{
					end=1;
					break;
				}
				atoi(rdbuf,&x);
				if(x>=10)
					atoi(rdbuf+3,&y);
				else 
					atoi(rdbuf+2,&y);
				x--;
				y--;
				if (check(x,y) )
				{
					chessMap[x][y]='@';
					break;
				}
				else
				{
					playerTwoStep--;
					printf("wrong position\n");
				}
			}
			if(end==1)
				break;
			if (isWin(x,y))
			{
				display();
				printf("player2 won the game\n");
				break;
			}
			display();			
		}	
	}
}

void calendar(int fd_stdin,int fd_stdout)
{
	printf("Please input the year and month: ");
	char rdbuf[128];
	int tmp = 0;
	int r = read(fd_stdin, rdbuf, 70);
	rdbuf[r] = 0;
	
	atoi(rdbuf,&tmp);
	int year=tmp;

	int t;
	atoi(rdbuf+5,&t);
	int month=t;

	cal(year,month);	
}

void print(int day,int num)
	{
		int a[7][7],i,j,sum=1;
		for(i=0,j=0;j<7;j++)
		{
			if(j<day)
				printf("    ");
			else
			{
				a[i][j]=sum;
				printf("   %d",sum++);
				// printf("aaa\n");
			}
		}
		printf("\n");
		for(i=1;sum<=num;i++)
		{
			for(j=0;sum<=num&&j<7;j++)
			{
				a[i][j]=sum;
				if (sum<10)
				{
					printf("   %d", sum++);
				}
				else{
					printf("  %d",sum++);
				}
			}
			printf("\n");
		}
	}


int judge(int year)
{
    if(year%4==0&&year%100!=0||year%400==0)
    return 1;
    else
    return 0;
}

int cal(int year,int month)
{
   int day,num,preday,strday;
   printf("********YEAR:%d  MONTH:%d*********\n",year,month);
   printf(" SUN MON TUE WED THU FRI SAT\n");
   switch(month)
   {
   case 1:
    num=31;
    preday=0;
   break;
   case 2:
        num=28;
        preday=31;
    break;
    case 3:
        num=31;
        preday=59;
    break;
    case 4:
        num=30;
        preday=90;
    break;
    case 5:
        num=31;
        preday=120;
    break;
    case 6:
        num=30;
        preday=151;
    break;
    case 7:
        num=31;
        preday=181;
    break;
    case 8:
        num=31;
        preday=212;
    break;
    case 9:
        num=30;
        preday=243;
    break;
    case 10:
        num=31;
        preday=273;
    break;
    case 11:
        num=30;
        preday=304;
    break;
    default:
        num=31;
        preday=334;
    }
    if(judge(year)&&month>2)
    	preday++;

    if(judge(year)&&month==2)
    	num=29;

    day=((year-1)*365+(year-1)/4-(year-1)/100+(year-1)/400+preday+1)%7;    
    print(day,num);
}

//File Tree
int treeNum = 0;
int size = 0; 
int FatherDirectory = -1;
int currPathDepth = 0;
char path[50][12]={0};

struct FileTreeArray
{
	int currDir;
	int fatherDir;
	int isDir;  
	char fileName[12];  

}fileTree[500];


void init()
{
	int i = 0;
	for (; i < 500; i++)
	{
		fileTree[i].currDir = -1;
		fileTree[i].fatherDir = -1;
		fileTree[i].isDir = -1;
	}
}

void creatFileTreeArray(char fileTreeInfo[])
{
	char currDir[4]={0};
	char fatherDir[4]={0};
	char isDir = 0;
	char fileName[12] = {0};
	char temp[12]={0};

	init();
	
	int count = 0,i=0,j=0;
	//i = 0;
	//j = 0;
	//for(;fileTreeInfo[j] == ' ';++j)
	//{
	//}
	for(;fileTreeInfo[j] != ';';)
	{
		count = 0;
		i = 0;
		while(count < 4)
		{
			temp[i] = fileTreeInfo[j];
			i++;
			j++;

			if(fileTreeInfo[j] == ' ')
			{
				j++;  
				if(count == 0)
				{
					atoi(temp,&(fileTree[size].currDir));
				}else if(count == 1)
				{
					atoi(temp,&(fileTree[size].fatherDir));		
				}else if(count == 2)
				{
					atoi(temp,&(fileTree[size].isDir));
				}else if(count == 3)
				{
					strcpy(fileTree[size].fileName, temp);
				}

				int k;
				for (k = 0; k < 12; ++k)
				{
					temp[k] = 0;
				}
				count++;
				i = 0;
			}
		}
		size++;
	}

	treeNum = size;
	size = fileTree[size-1].currDir + 1;
}

void getTreeInfo(char fileTreeInfo[])
{
	fileTreeInfo[0]=0;
	char temp[12]={0};

	int count = 0;
	int i = 0;
	for(;count < treeNum && i < 500;i++)
	{

		if(fileTree[i].currDir != -1)
		{
			itoaDec(temp,fileTree[i].currDir);
			strcat(fileTreeInfo,temp);
			strcat(fileTreeInfo," ");

			itoaDec(temp,fileTree[i].fatherDir);

			strcat(fileTreeInfo,temp);
			strcat(fileTreeInfo," ");

			if(fileTree[i].isDir == 1)
			{
				temp[0] = '1';
				temp[1] = 0;
			}else
			{
				temp[0] = '0';
				temp[1] = 0;
			}
			strcat(fileTreeInfo,temp);
			strcat(fileTreeInfo," ");

			strcat(fileTreeInfo,fileTree[i].fileName);
			strcat(fileTreeInfo," ");

			count++;
		}
	}
	strcat(fileTreeInfo,";");

}

void showTree()
{
	int i = 0;
	for(;i < size;i++)
	{
		if(fileTree[i].currDir!=-1)
		{
			printf("currentDirectory:%d    ",fileTree[i].currDir);
			printf("fatherDirectory:%d    ",fileTree[i].fatherDir);
			printf("isDirectory:%d    ",fileTree[i].isDir);
			printf("fileName:%s    ",fileTree[i].fileName);
			printf("\n");
		}
	}
}

void saveFileTree()
{
	int fd = -1;
	int buf[2014] = {0};

	char treeInfo[2048]={0};
	getTreeInfo(treeInfo);

	fd = open("TreeRecord", O_RDWR);
	if (fd == -1)
	{
		printf("Failed to open 'TreeRecord'!\n");
		return;
	}
	strcpy(buf,treeInfo);

	write(fd, buf, 1024);
	close(fd);
}

void readFileTree(char buf[])
{
	int fd = -1;
	int n;

	fd = open("TreeRecord", O_RDWR);
	if (fd == -1)
	{
		fd = open("TreeRecord", O_CREAT | O_RDWR);
		if (fd == -1)
			return;
		buf[0] = ';';
		buf[1] = 0;

		write(fd, buf, 2);
		printf("File created: (fd %d)\n",  fd);
		close(fd);

		fd = open("TreeRecord", O_RDWR);
	}
	
	n = read(fd, buf, 2048);
	close(fd);
}

void printPath()
{
	if(currPathDepth == 0)
	{
		printf("/");
		return;
	}
	int i = 0;
	for(; i < currPathDepth; i++)
	{
		printf("/%s", path[i]);
	}
}
void printCurrentFile()
{
	int i = 0;
	for (; i < size; i++)
	{
		if(fileTree[i].currDir != -1 && fileTree[i].fatherDir == FatherDirectory)
		{
			if(fileTree[i].isDir == 0)
			{
				printf("%s ---- File \n", fileTree[i].fileName);
			}
			else
			{
				printf("%s ---- directory \n", fileTree[i].fileName);
			}
		}
	}
}

void openDir(char filename[])
{
	int i = 0;
	for (; i < size; i++)
	{
		if(	fileTree[i].currDir != -1 && strcmp(fileTree[i].fileName,filename) == 0 
			&& fileTree[i].fatherDir == FatherDirectory && fileTree[i].isDir == 1)
		{
			strcpy(path[currPathDepth],fileTree[i].fileName);		
			FatherDirectory = fileTree[i].currDir;
			currPathDepth++;
			return;
		}
	}
	printf("fail to open %s\n", filename);
}

void back()
{
	int i = 0;
	for (; i < size; i++)
	{
		if(fileTree[i].currDir == FatherDirectory && fileTree[i].isDir == 1)
		{
			FatherDirectory = fileTree[i].fatherDir;
			currPathDepth--;
			return;
		}
	}
}

void createDir(char filename[])
{
	int i = 0;
	for (; i < size; i++)
	{
		if(strcmp(fileTree[i].fileName,filename) == 0 && fileTree[i].isDir == 1)
		{
			printf("Such directory exists\n");
			return;
		}
	}

	fileTree[size].currDir = size;
	fileTree[size].fatherDir = FatherDirectory;
	fileTree[size].isDir = 1;
	strcpy(fileTree[size].fileName ,filename);
	size++;
	treeNum++;
}

int isThereFile(char filename[])
{
	int i = 0;
	for (; i < size; ++i)
	{
		if(strcmp(fileTree[i].fileName,filename) == 0 && fileTree[i].fatherDir == FatherDirectory)
		{
			return 1;
		}
	}
	return 0;
}

/*======================================================================*
                               TestB
 *======================================================================*/
void TestB()
{
	char tty_name[] = "/dev_tty1";

	int fd_stdin  = open(tty_name, O_RDWR);
	assert(fd_stdin  == 0);
	int fd_stdout = open(tty_name, O_RDWR);
	assert(fd_stdout == 1);

	char rdbuf[128];
	char cmd[8];
	char filename[120];
	char buf[1024];
	int m,n;

	char treeBuf[2048]={0};

	readFileTree(treeBuf);
	creatFileTreeArray(treeBuf);

	printf("                      ==================================\n");
	printf("                                  File system          \n");
	printf("                      ==================================\n");
	printf("\n");
	printf("=============================================================================\n");
	printf(" /////     create xxx   -------- Create a new file               //////\n");
	printf(" /////     write xxx    -------- Write at the end of the file    //////\n");
	printf(" /////     read xxx     -------- Read the file                   //////\n");
	printf(" /////     delete xxx   -------- Delete the file                 //////\n");
	printf(" /////     help         -------- Help screen                     //////\n");
	printf(" /////     show         -------- Show all the files              //////\n");
	printf(" /////     cd yyy       -------- cd the directory                //////\n");
	printf(" /////     mkdir yyy    -------- create a new directory          //////\n");
	printf(" /////     back         -------- back to the pre                 //////\n");
	printf("  p.s. 'xxx' is the file name        'yyy' is the directory name\n");
	printf("==============================================================================\n");	
	while (1) {
		printPath();
		printf(" $ :");
		int r = read(fd_stdin, rdbuf, 70);
		rdbuf[r] = 0;

		if(strcmp(rdbuf, "show") == 0)
		{
			showTree();
		}
		else if(strcmp(rdbuf, "back") == 0)
		{
			back();
		}
		else if (strcmp(rdbuf, "help") == 0)
		{
			printf("=============================================================================\n");
			printf(" /////     create xxx   -------- Create a new file               //////\n");
			printf(" /////     write xxx    -------- Write at the end of the file    //////\n");
			printf(" /////     read xxx     -------- Read the file                   //////\n");
			printf(" /////     delete xxx   -------- Delete the file                 //////\n");
			printf(" /////     help         -------- Help screen                     //////\n");
			printf(" /////     show         -------- Show all the files              //////\n");
			printf(" /////     cd yyy       -------- cd the directory                //////\n");
			printf(" /////     mkdir yyy    -------- create a new directory          //////\n");
			printf(" /////     back         -------- back to the pre                 //////\n");
			printf("  p.s. 'xxx' is the file name        'yyy' is the directory name\n");
			printf("==============================================================================\n");		
		}
		else if (strcmp(rdbuf, "dir") == 0)
		{
			printCurrentFile();
			continue;
		}
		else
		{
			int fd;
			int i = 0;
			int j = 0;
			char temp = -1;
			//command
			while(rdbuf[i]!=' ' && rdbuf[i] != 0)
			{
				cmd[i] = rdbuf[i];
				i++;
			}
			cmd[i++] = 0;
			//filename
			while(rdbuf[i] != 0)
			{
				filename[j] = rdbuf[i];
				i++;
				j++;
			}
			filename[j] = 0;

			if(strcmp(cmd, "mkdir") == 0)
			{
				createDir(filename);

				saveFileTree();
			}
			else if(strcmp(cmd, "cd") == 0)
			{
				openDir(filename);
				
			}
			else if (strcmp(cmd, "create") == 0)
			{
				fd = open(filename, O_CREAT | O_RDWR);
				if (fd == -1)
				{
					printf("File exists\n");
					continue ;
				}
				printf("File created: %s", filename);
				printf("\n");
				close(fd);

				fileTree[size].currDir = size;
				fileTree[size].fatherDir = FatherDirectory;
				fileTree[size].isDir = 0;  
				strcpy(fileTree[size].fileName, filename);
				size++;
				treeNum++;

				saveFileTree();

			}
			else if (strcmp(cmd, "read") == 0)
			{
				if(isThereFile(filename) == 0)
				{
					printf("No such file\n");
					continue;
				}
				fd = open(filename, O_RDWR);
				if (fd == -1)
				{
					printf("No such file\n");
					continue ;
				}
				
				n = read(fd, buf, 1024);
				
				printf("%s\n", buf);
				close(fd);

			}
			else if (strcmp(cmd, "write") == 0)
			{
				if(isThereFile(filename) == 0)
				{
					printf("No such file\n");
					continue;
				}
				fd = open(filename, O_RDWR);
				if (fd == -1)
				{
					printf("No such file!\n");
					continue ;
				}

				m = read(fd_stdin, rdbuf,80);
				rdbuf[m] = 0;
				
				n = write(fd, rdbuf, m+1);
				close(fd);
			}
			else if (strcmp(cmd, "delete") == 0)
			{
				if(isThereFile(filename) == 0)
				{
					printf("No such file\n");
					continue;
				}

				//delete file
				m=unlink(filename);
				if (m == 0)
				{
					printf("File deleted!\n");

					int i = 0;
					for (; i < size; ++i)
					{
						if(strcmp(fileTree[i].fileName,filename) == 0)
						{
							fileTree[i].currDir = -1;
							continue;
						}
					}
					treeNum--;
					saveFileTree();
					continue;
				}
				else
				{
					printf("No such file\n");
					continue;
				}
			}
			else 
			{
				printf("Command not found, Please check!\n");
				continue;
			}						
		}			
	}

	assert(0); /* never arrive here */
}


void TestC()
{
	//printf("abc");
	spin("TestC");
}

TTY *gameTty = tty_table+2;

int board[4][4];     /* 游戏数字面板，抽象为二维数组 */
int score;           /* 游戏的分 */
int best;            /* 游戏最高分 */
int if_need_add_num; /* 是否需要生成随机数标志，1表示需要，0表示不需要 */
int if_game_over;    /* 是否游戏结束标志，1表示游戏结束，0表示正常 */
int cmd;

void start(int fd_stdin, int fd_stdout)
{
	int fd;
	int n;
	const char filename[] = "abc";
	char bufw[128];
	int rd_bytes = 7;
	char *bufr;
	//char best_score[rd_bytes];

	char rdbuf[128];	

	//assert(rd_bytes <= strlen(bufw));

	/* open */
	fd = open(filename, O_RDWR);
	assert(fd != -1);
	//printf("File opened. fd: %d\n", fd);

	/* read */
	n = read(fd, bufr, rd_bytes);
	//assert(n == rd_bytes);
	bufr[n] = 0;
	//printf("%d bytes read: %s\n", n, bufr);

	/* close */
	close(fd);	

	int a=0;
	atoi(bufr, &a);
	best=a;

	reset_game();
	//clearScreen();
	while(1)
	{
		//clear();
		sys_clear(gameTty);
		refresh_show();
		int r = read(fd_stdin, rdbuf, 70);
		rdbuf[r] = 0;

		if (if_game_over) /* 判断是否需已经输掉游戏 */
        	{
           		if (strcmp(rdbuf, "y") == 0) /* 重玩游戏 */
             		{
                 		reset_game();
                 		continue;
             		}
             		else if (strcmp(rdbuf, "n") == 0) /* 退出 */
             		{
                 		return;
            		 }
             		else
             		{
                 		continue;
             		}
		}
        
        	if_need_add_num = 0;  //先设定不默认需要生成随机数，需要时再设定为1 

		 if (strcmp(rdbuf, "w") == 0)
        	{
			move_up();
        	}
		else if (strcmp(rdbuf, "a") == 0)
		{
			move_left();
		}
		else if (strcmp(rdbuf, "s") == 0)
		{
			move_down();
		}
		else if (strcmp(rdbuf, "d") == 0)
		{
			move_right();
		}

		if(score>best)
		{
			best=score;

			intToStr(best,bufw);
			int x=strlen(bufw);
			bufw[x]=' ';
			bufw[x+1]='1';

			fd = open(filename,O_RDWR);
			assert(fd != -1);
			//printf("File created. fd: %d\n", fd);

			/* write */
			n = write(fd, bufw, strlen(bufw));
			assert(n == strlen(bufw));

			/* close */
			close(fd);			
		}
		
		// score > best ? best = score : 1; /* 打破得分纪录 */
        
        	if (if_need_add_num) /* 默认为需要生成随机数时也同时需要刷新显示，反之亦然 */
        	{
            		add_rand_num();
            		//refresh_show();
        	}
	}
}

/*
 * 如下四个函数，实现上下左右移动时数字面板的变化算法
 * 左和右移动的本质一样，区别仅仅是列项的遍历方向相反
 * 上和下移动的本质一样，区别仅仅是行项的遍历方向相反
 * 左和上移动的本质也一样，区别仅仅是遍历时行和列互换
 */ 

/* 左移 函数定义 */
void move_left()
{
    /* 变量i用来遍历行项的下标，并且在移动时所有行相互独立，互不影响 */
    //printf("qq"); 
    //printf("bb\n");
    int i;
    for (i = 0; i < 4; i++)
    {
        /* 变量j为列下标，变量k为待比较（合并）项的下标，循环进入时k<j */
        int j,k;
        for (j = 1, k = 0; j < 4; j++)
        {
            if (board[i][j] > 0) /* 找出k后面第一个不为空的项，下标为j，之后分三种情况 */
            {
                if (board[i][k] == board[i][j]) /* 情况1：k项和j项相等，此时合并方块并计分 */
                {
                    score += board[i][k++] <<= 1;
                    board[i][j] = 0;
                    if_need_add_num = 1; /* 需要生成随机数和刷新界面 */ 
                }
                else if (board[i][k] == 0) /* 情况2：k项为空，则把j项赋值给k项，相当于j方块移动到k方块 */
                {
                    board[i][k] = board[i][j];
                    board[i][j] = 0;
                    if_need_add_num = 1;
                }
                else /* 情况3：k项不为空，且和j项不相等，此时把j项赋值给k+1项，相当于移动到k+1的位置 */
                {
                    board[i][++k] = board[i][j];
                    if (j != k) /* 判断j项和k项是否原先就挨在一起，若不是则把j项赋值为空（值为0） */
                    {
                        board[i][j] = 0;
                        if_need_add_num = 1;
                    }
                }
            }
        }
    }
}

/* 右移 函数定义 */
void move_right()
{
    /* 仿照左移操作，区别仅仅是j和k都反向遍历 */
    int i;
    for (i = 0; i < 4; i++)
    {
    	int j,k;
        for (j = 2, k = 3; j >= 0; j--)
        {
            if (board[i][j] > 0)
            {
                if (board[i][k] == board[i][j])
                {
                    score += board[i][k--] <<= 1;
                    board[i][j] = 0;
                    if_need_add_num = 1;
                }
                else if (board[i][k] == 0)
                {
                    board[i][k] = board[i][j];
                    board[i][j] = 0;
                    if_need_add_num = 1;
                }
                else
                {
                    board[i][--k] = board[i][j];
                    if (j != k)
                    {
                        board[i][j] = 0;
                        if_need_add_num = 1;
                    }
                }
            }
        }
    }
}

/* 上移 函数定义 */
void move_up()
{
    /* 仿照左移操作，区别仅仅是行列互换后遍历 */
    int i;
    for (i = 0; i < 4; i++)
    {
    	int j,k;
        for (j = 1, k = 0; j < 4; j++)
        {
            if (board[j][i] > 0)
            {
                if (board[k][i] == board[j][i])
                {
                    score += board[k++][i] <<= 1;
                    board[j][i] = 0;
                    if_need_add_num = 1;
                }
                else if (board[k][i] == 0)
                {
                    board[k][i] = board[j][i];
                    board[j][i] = 0;
                    if_need_add_num = 1;
                }
                else
                {
                    board[++k][i] = board[j][i];
                    if (j != k)
                    {
                        board[j][i] = 0;
                        if_need_add_num = 1;
                    }
                }
            }
        }
    }
}

/* 下移 函数定义 */
void move_down()
{
    /* 仿照左移操作，区别仅仅是行列互换后遍历，且j和k都反向遍历 */
    int i;
    for (i = 0; i < 4; i++)
    {
    	int j,k;
        for (j = 2, k = 3; j >= 0; j--)
        {
            if (board[j][i] > 0)
            {
                if (board[k][i] == board[j][i])
                {
                    score += board[k--][i] <<= 1;
                    board[j][i] = 0;
                    if_need_add_num = 1;
                }
                else if (board[k][i] == 0)
                {
                    board[k][i] = board[j][i];
                    board[j][i] = 0;
                    if_need_add_num = 1;
                }
                else
                {
                    board[--k][i] = board[j][i];
                    if (j != k)
                    {
                        board[j][i] = 0;
                        if_need_add_num = 1;
                    }
                }
            }
        }
    }
}


void reset_game()
{

    score = 0;
    if_need_add_num = 1;
    if_game_over = 0;
    
    /* 了解到游戏初始化时出现的两个数一定会有个2，所以先随机生成一个2，其他均为0 */ 
    int n = ticks % 16;
    int i;
    for (i = 0; i < 4; i++)
    {
    	int j;
        for (j = 0; j < 4; j++)
        {
            board[i][j] = (n-- == 0 ? 2 : 0);
        }
    }
    
    /* 前面已经生成了一个2，这里再生成一个随机的2或者4，且设定生成2的概率是4的两倍 */
    add_rand_num();
    
    /* 在这里刷新界面并显示的时候，界面上已经默认出现了两个数字，其他的都为空（值为0） */
    //system("cls");
    refresh_show();
}

/* 生成随机数 函数定义 */
void add_rand_num()
{
    //srand(time(0));
    int n = score % get_null_count();/* 确定在何处空位置生成随机数 */
    int i;
    for (i = 0; i < 4; i++)
    {
    	int j;
        for (j = 0; j < 4; j++)
        {
            if (board[i][j] == 0 && n-- == 0) /* 定位待生成的位置 */
            {
                board[i][j] = (score % 3 ? 2 : 4);/* 确定生成何值，设定生成2的概率是4的概率的两倍 */
                return;
            }
        }
    }
}

/* 获取空位置数量 函数定义 */
int get_null_count()
{
    int n = 0;
    int i;
    for (i = 0; i < 4; i++)
    {
    	int j;
        for (j = 0; j < 4; j++)
        {
            board[i][j] == 0 ? n++ : 1;
        }
    }
    return n;
}

/* 检查游戏是否结束 函数定义 */
void check_game_over()
{
	int i;
    for (i = 0; i < 4; i++)
    {
    	int j;
        for (j = 0; j < 3; j++)
        {
            /* 横向和纵向比较挨着的两个元素是否相等，若有相等则游戏不结束 */
            if (board[i][j] == board[i][j+1] || board[j][i] == board[j+1][i])
            {
                if_game_over = 0;
                return;
            }
        }
    }
    if_game_over = 1;
}


/* 刷新界面 函数定义 */
void refresh_show()
{
   /* 重设光标输出位置方式清屏可以减少闪烁，system("cls")为备用清屏命令，均为Windows平台相关*/
    //COORD pos = {0, 0};
    //SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
    //clearScreen();

    printf("\n\n");
    printf("                  GAME: 2048     SCORE: %d    BEST: %d\n", score, best);
    printf("             --------------------------------------------------\n\n");
    
    /* 绘制表格和数字 */
    printf("                        ---------------------\n");
    int i;
    for (i = 0; i < 4; i++)
    {
        printf("                        |");
        int j;
        for (j = 0; j < 4; j++)
        {
            if (board[i][j] != 0)
            {
                if (board[i][j] < 10)
                {
                    printf("  %d |", board[i][j]);                    
                }
                else if (board[i][j] < 100)
                {
                    printf(" %d |", board[i][j]);
                }
                else if (board[i][j] < 1000)
                {
                    printf(" %d|", board[i][j]);
                }
                else if (board[i][j] < 10000)
                {
                    printf("%d|", board[i][j]);
                }
                else
                {
                    int n = board[i][j];
                    int k;
                    for (k = 1; k < 20; k++)
                    {
                        n >>= 1;
                        if (n == 1)
                        {
                            printf("2^%02d|", k); /* 超过四位的数字用2的幂形式表示，如2^13形式 */
                            break;
                        }
                    }
                }
            }
            else printf("    |");
        }
        
        if (i < 3)
        {
            printf("\n                        ---------------------\n");
        }
        else
        {
            printf("\n                        ---------------------\n");
        }
    }
    
    printf("\n");
    printf("             --------------------------------------------------\n");
    printf("                   W:UP    A:LEFT    D:RIGHT    S:DOWN    \n");
    
    if (get_null_count() == 0)
    {
        check_game_over();
        if (if_game_over) /* 判断是否输掉游戏 */
        {
	    printf("\n");
            printf("                                  GAME OVER!\n");
	    printf("                                TRY AGAIN [Y/N] ");
        }
    }
}

void TestD()
{
	char tty_name[] = "/dev_tty2";

	int fd_stdin  = open(tty_name, O_RDWR);
	assert(fd_stdin  == 0);
	int fd_stdout = open(tty_name, O_RDWR);
	assert(fd_stdout == 1);

	//char rdbuf[128];
	//char cmd[8];
	//char filename[120];
	//char buf[1024];
	//int m,n;

	int j, i;
    	for (j = 0; j < 4; j++)             //对4*4进行初始赋值为0
        	for (i = 0; i < 4; i++)
            	board[j][i] = 0;
    	score=0;
    	//best=0;
    	start(fd_stdin, fd_stdout);
   	while(1);
   	return 0;

	assert(0); /* never arrive here */
}

void abcd()
{
	char tty_name[] = "/dev_tty3";

	int fd_stdin  = open(tty_name, O_RDWR);
	assert(fd_stdin  == 0);
	int fd_stdout = open(tty_name, O_RDWR);
	assert(fd_stdout == 1);
	
	int j, i;
    	for (j = 0; j < 4; j++)             //对4*4进行初始赋值为0
        	for (i = 0; i < 4; i++)
            	board[j][i] = 0;
    	score=0;
    	//best=0;
    	start(fd_stdin, fd_stdout);
   	while(1);
   	return 0;

	assert(0); /* never arrive here */
}


void timer(int fd_stdin,int fd_stdout)
{
		int temperature;

	while (1)
	{
		printf("*****************************************\n");
		printf("|   Please select one of convertions:   |\n");
		printf("|    c:  Convert Celsius to Fahrenheit  |\n");
		printf("|    f:  Convert Fahrenheit to Celsius  |\n");
		printf("|    q:  Quit                           |\n");
		printf("*****************************************\n");
		char rdbuf[128];
		//char t;

		int r = read(fd_stdin, rdbuf, 70);
		rdbuf[r] = 0;
		if (strcmp(rdbuf, "c") == 0)
		{
			printf("*****************************************\n");
			printf("|   Please input Celsius temperature:");
			int r = read(fd_stdin, rdbuf, 70);
			rdbuf[r] = 0;
			atoi(rdbuf,&temperature);
			//printf("%d",temperature);
			temperature=temperature*2+32;
			printf("|   The Fahrenheit temperature is:%d|\n", temperature);
			printf("*****************************************\n");
			break;
		}
		else if (strcmp(rdbuf, "f") == 0)
		{
			printf("*****************************************\n");
			printf("|   Please input Fahrenheit temperature:");
			int r = read(fd_stdin, rdbuf, 70);
			rdbuf[r] = 0;
			atoi(rdbuf,&temperature);
			temperature=5*(temperature-32)/9;
			printf("|   The Celsius temperature is : %d |\n",temperature);
			printf("*****************************************\n");
			break;
		}
		else if (strcmp(rdbuf, "q") == 0)
		{
			break;
		}
		else
		{
			printf("Your Command Error!temperatureut Again\n");
		}
	}
}


/*****************************************************************************
 *                                panic
 *****************************************************************************/
PUBLIC void panic(const char *fmt, ...)
{
	int i;
	char buf[256];

	/* 4 is the size of fmt in the stack */
	va_list arg = (va_list)((char*)&fmt + 4);

	i = vsprintf(buf, fmt, arg);

	printl("%c !!panic!! %s", MAG_CH_PANIC, buf);

	/* should never arrive here */
	__asm__ __volatile__("ud2");
}

void clear()
{
	clear_screen(0,console_table[current_console].cursor);
	console_table[current_console].crtc_start = 0;
	console_table[current_console].cursor = 0;
	
}

void clearScreen()
{
	int i;
	disp_pos=0;
	for(i=0;i<80*25;i++)
	{
		disp_str(" ");
	}
	disp_pos=0;
}

void help()
{
	clearScreen();
	disp_color_str("\n", 0x1);
	disp_color_str("      *////////////////////////////////////////////////////////*\n", 0xE);
	disp_color_str("      *////", 0xE);disp_color_str("  help         --------  show the help menu", 0xB);disp_color_str("     ////*\n", 0xE);
	disp_color_str("      *////", 0xE);disp_color_str("  cltr+F2      --------  file system         ", 0xB);disp_color_str("   ////*\n", 0xE);
	disp_color_str("      *////", 0xE);disp_color_str("  cltr+F3      --------  2048 game   ", 0xB);disp_color_str("           ////*\n", 0xE);
	disp_color_str("      *////", 0xE);disp_color_str("  t            --------  temperature ", 0xB);disp_color_str("           ////*\n", 0xE);
	disp_color_str("      *////", 0xE);disp_color_str("  calendar     --------  calendar    ", 0xB);disp_color_str("           ////*\n", 0xE);
	disp_color_str("      *////", 0xE);disp_color_str("  chess        --------  chess       ", 0xB);disp_color_str("           ////*\n", 0xE);
	disp_color_str("      *////", 0xE);disp_color_str("  kill 5~7     --------  kill the process 5~7", 0xB);disp_color_str("   ////*\n", 0xE);
	disp_color_str("      *////", 0xE);disp_color_str("  start 5~7    --------  start the process 5~7  ", 0xB);disp_color_str("////*\n", 0xE);
	disp_color_str("      *////", 0xE);disp_color_str("  show         --------  show the process state", 0xB);disp_color_str(" ////*\n", 0xE);
	disp_color_str("      *////", 0xE);disp_color_str("  exit         --------  exit", 0xB);disp_color_str("                   ////*\n", 0xE);
	disp_color_str("      *////////////////////////////////////////////////////////*\n", 0xE);
	disp_color_str("\n", 0x1);
    disp_color_str("====================================",0x04);disp_color_str("===================================\n",0x04);	
}


/*======================================================================*
				animation
*=======================================================================*/

void DisPlayAnimation()//开机动画
{
	int color = 0x7f;

	
	clearScreen();
	disp_str("\n");
	disp_str("\n");
	disp_str("\n");
	disp_str("\n");
	disp_str("\n");
	disp_str("           HHHHHHHHHHH\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("          H           H\n");
	disp_str("         H             H\n");
	disp_str("         H             H\n");
	disp_str("         H             H\n");
	disp_str("         H             H\n");
	disp_str("         H             H\n");
	disp_str("         H             H\n");
	disp_str("         H             H\n");
	disp_str("         H             H\n");
	disp_str("         H             H\n");
	disp_str("         H             H\n");
	disp_str("         HHHHHHHHHHHHHHH\n");
	sec_delay(1); 



	clearScreen();
	disp_str("\n");
	disp_str("\n");
	disp_str("\n");
	disp_str("\n");
	disp_str("\n");
	disp_str("           HHHHHHHHHHH\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("          H           H\n");
	disp_str("         H             H\n");
	disp_str("         H             H\n");
	disp_str("         H             H\n");
	disp_str("         H             H\n");
	disp_str("         H             H\n");
	disp_str("         H             H\n");
	disp_str("         H             H\n");
	disp_str("         H             H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         HHHHHHHHHHHHHHH\n");
	sec_delay(1); 

		

		

	clearScreen();
	disp_str("\n");
	disp_str("\n");
	disp_str("\n");
	disp_str("\n");
	disp_str("\n");
	disp_str("           HHHHHHHHHHH\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("          H           H\n");
	disp_str("         H             H\n");
	disp_str("         H             H\n");
	disp_str("         H             H\n");
	disp_str("         H             H\n");
	disp_str("         H             H\n");
	disp_str("         H             H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         HHHHHHHHHHHHHHH\n");
	sec_delay(1); 




	clearScreen();
	disp_str("\n");
	disp_str("\n");
	disp_str("\n");
	disp_str("\n");
	disp_str("\n");
	disp_str("           HHHHHHHHHHH\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("          H           H\n");
	disp_str("         H             H\n");
	disp_str("         H             H\n");
	disp_str("         H             H\n");
	disp_str("         H             H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         HHHHHHHHHHHHHHH\n");
	sec_delay(1); 




	clearScreen();
	disp_str("\n");
	disp_str("\n");
	disp_str("\n");
	disp_str("\n");
	disp_str("\n");
	disp_str("           HHHHHHHHHHH\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("          H           H\n");
	disp_str("         H             H\n");
	disp_str("         H             H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         HHHHHHHHHHHHHHH\n");
	sec_delay(1); 


	clearScreen();
	disp_str("\n");
	disp_str("\n");
	disp_str("\n");
	disp_str("\n");
	disp_str("\n");
	disp_str("           HHHHHHHHHHH\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("          H           H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         HHHHHHHHHHHHHHH\n");
	sec_delay(1); 



	clearScreen();
	disp_str("\n");
	disp_str("\n");
	disp_str("\n");
	disp_str("\n");
	disp_str("\n");
	disp_str("           HHHHHHHHHHH\n");
	disp_str("           H         H\n");
	disp_str("           H         H\n");
	disp_str("           H");
	disp_color_str("AAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("           H");
	disp_color_str("AAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("           H");
	disp_color_str("AAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("           H");
	disp_color_str("AAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("          H");
	disp_color_str("AAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         HHHHHHHHHHHHHHH\n");
	sec_delay(1); 


	clearScreen();
    	disp_color_str("  o      o          oo      o    \n",0x0B);
    	disp_color_str("     o          o       o        \n",0x0B);
    	disp_color_str("  o          o     o        oo   \n",0x0B);
    	disp_color_str("   o  o      o          ooo      \n",0x0B);
    	disp_color_str("ooo        o   o    oo   o o     \n",0x0B);
  
	disp_str("           HHHHHHHHHHH\n");
	disp_str("           H");
	disp_color_str("AAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("           H");
	disp_color_str("AAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("           H");
	disp_color_str("AAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("           H");
	disp_color_str("AAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("           H");
	disp_color_str("AAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("           H");
	disp_color_str("AAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("          H");
	disp_color_str("AAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         H");
	disp_color_str("AAAAAAAAAAAAA",0x33);
	disp_str("H\n");
	disp_str("         HHHHHHHHHHHHHHH\n");
	sec_delay(1);

	clearScreen();
	disp_str("\n\n\n\n\n");
	disp_color_str("               M         M       II        N     N        II       X    X    \n",0xE); 	
	disp_color_str("               MM       MM       II        NN    N        II        X  X    \n",0xE); 	
	disp_color_str("               M M     M M       II        N N   N        II         XX    \n",0xE); 	
	disp_color_str("               M  M   M  M       II        N  N  N        II         XX    \n",0xE); 	
	disp_color_str("               M   M M   M       II        N   N N        II        X  X    \n",0xE); 	
	disp_color_str("               M    M    M       II        N    NN        II       X    X    \n",0xE);  	
	disp_str("\n\n\n"); 	
	disp_color_str("                   ----------------- Made BY ----------------\n\n",0xB); 	
	disp_color_str("                   --Siyuan Lu    Xuguang Zhu  Zhaoyu Zhang--\n\n",0xF); 	
	disp_color_str("                   ------------      WELCOME     ---------\n\n",0xD);
	sec_delay(1);


	clearScreen();

}

/*======================================================================*
			display goodbye
*=======================================================================*/

void displayGoodBye()
{
	clearScreen();
	disp_str("\n\n\n");
	disp_color_str("             GGGG    OOO    OOO    DDDD       BBBB    Y    Y    EEEEE   \n",0xE); 	
	disp_color_str("            G       O   O  O   O   D   D      B    B   Y  Y     E   \n",0xE); 	
	disp_color_str("            G       O   O  O   O   D    D     B    B     Y      E   \n",0xE); 	
	disp_color_str("            G  GGG  O   O  O   O   D    D     BBBBB      Y      EEEEE   \n",0xE); 	
	disp_color_str("            G    G  O   O  O   O   D    D     B    B     Y      E   \n",0xE); 	
	disp_color_str("            G    G  O   O  O   O   D   D      B    B     Y      E   \n",0xE); 
	disp_color_str("             GGGGG   OOO    OOO    DDDD       BBBB       Y      EEEEE   \n",0xE);  	
	disp_str("\n\n"); 	
	disp_color_str("                   ----------------- Made BY ---------------\n\n",0xB); 	
	disp_color_str("                   --Siyuan Lu    Xuguang Zhu  Zhaoyu Zhang--\n\n",0xF); 	
	disp_color_str("                   ------------      Goodbye     -----------\n\n",0xD);
	disp_str("\n\n");
}
